import { NextFunction, Request, Response } from 'express';

export function Authorizer(req: Request & any, res: Response, next: NextFunction) {
    try {
        const appId = req.params.appId;
        const accessStatus = req.user.authorized_apps.inclues(appId);
        if(accessStatus === true){
            console.info("authorized");
            next()
        } else {
            res.sendStatus(403)
        }
    } catch (error) {
        res.sendStatus(500)
    }
}