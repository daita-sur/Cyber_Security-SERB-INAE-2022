import { NextFunction, Request, Response } from 'express';
var jwt = require('jsonwebtoken');

export async function Authenticator(req: Request & any, res: Response, next: NextFunction) {
    try {
        const decoded = await jwt.verify(req.headers['authorization']?.split(' ')[1], "mySuperSecretKey");
        if(decoded){
            req.user = decoded;
            next();
        }else {
            res.sendStatus(403);
        }
    } catch (error) {
        res.sendStatus(500);
    }
}