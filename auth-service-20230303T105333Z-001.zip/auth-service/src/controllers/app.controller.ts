import { Router, Request, Response  } from 'express';
import { Authenticator } from '../utils/authenticator';
import { Authorizer } from '../utils/authorizer';

const router = Router();

router.get('/:appId', Authenticator, Authorizer, (req: Request, res: Response)=> {
    res.json({
        message: `Authorized to use ${req.params.appId}`
    })
})

export default router;