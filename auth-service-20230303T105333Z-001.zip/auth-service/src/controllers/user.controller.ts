import { Router, Request, Response } from 'express';
import {hash, compare} from 'bcrypt';
var jwt = require('jsonwebtoken');
import userModel from '../models/users';

const router = Router();

router.post('/signup', async (req: Request, res: Response) => {
    try {
        const user: any = {};
        user.email = req.body.email;
        user.password = await hash(req.body.password, 10);
        const newUser = new userModel(user);
        const savedUser = await newUser.save();
        if (savedUser) {
            res.json({
                message: "User created successfully"
            });
        }else {
            res.status(500).json({
                message: "An error occured while creating a user"
            });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "An error occured while creating a user"
        });
    }
});

router.post('/login', async (req: Request, res: Response) => {
    try {
        const creds = req.body;
        const user = await userModel.findOne({email: creds.email});
        if(user) {
            if(await compare(creds.password, (user.password || ''))){
                const strippedUser = {...user}
                delete strippedUser.password;
                const token = await jwt.sign(strippedUser, "mySuperSecretKey", {expiresIn: "2 days"});
                res.json({
                    "message": "User signin sucessfull",
                    "token": token
                });
            } else {
                res.status(403).json({
                    message: 'incorrect username or password'
                });
            }
        }else {
            res.status(403).json({
                message: 'incorrect username or password'
            });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "An error occured while signin"
        });
    }
});

export default router;