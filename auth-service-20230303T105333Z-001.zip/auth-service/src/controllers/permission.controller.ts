import { Router, Request, Response } from 'express';
import userModel from '../models/users';

const router = Router();

router.patch('/grant', async (req: Request, res:Response) => {
    try {
        const user = await userModel.findOne(req.body.id);
        user?.authorized_apps.push(...req.body.authorized_apps);
        const savedUser = await user?.save();
        if(savedUser){
            res.json({
                message: "user authorized"
            });
        } else {
            res.status(500).json({
                message: "An error occured"
            });
        }
    } catch (error) {
        res.status(500).json({
            message: "An error occured"
        });
    }
});


router.patch('/revoke', async (req: Request, res:Response) => {
    try {
        const user = await userModel.findOne(req.body.id);
        if (user){
            const diff = user.authorized_apps.filter((authorized_app) => {
                return !req.body.apps_to_remove.includes(authorized_app)
            })
            user.authorized_apps = [...diff]
            const savedUser = await user?.save();
            if(savedUser){
                res.json({
                    message: "user authorized"
                });
            } else {
                res.status(500).json({
                    message: "An error occured"
                });
            }
        } else {
            res.status(404).json({
                message: "user not found"
            });
        }
    } catch (error) {
        res.status(500).json({
            message: "An error occured"
        });
    }
});

router.patch('/request', async (req: Request, res:Response) => {
    try {
        const user = await userModel.findOne(req.body.id);
        user?.pending_authorizations.push(...req.body.requested_apps);
        const savedUser = await user?.save();
        if(savedUser){
            res.json({
                message: "Authorization request noted"
            });
        } else {
            res.status(500).json({
                message: "An error occured"
            });
        }
    } catch (error) {
        res.status(500).json({
            message: "An error occured"
        });
    }
});

router.get('/pending', async (req: Request, res:Response) => {
    try {
        const pendingPermissions = await userModel.find({}, {email: 1, pending_authorizations: 1});
        res.json({
            message: "pending permissions fetched",
            pendingPermissions: pendingPermissions
        })
    } catch (error) {
        res.status(500).json({
            message: "An error occured"
        });
    }
})

export default router;