import express from 'express';
import permissionController from './controllers/permission.controller';
import userController from './controllers/user.controller';
import appController from './controllers/app.controller';
import mongoose from 'mongoose';

const app = express();
const PORT = process.env.PORT ?? 3000;

app.use(express.json());

app.use('/user', userController);
app.use('/app', appController);
app.use('/permission', permissionController);

mongoose.connect("mongodb+srv://shams:nYrfl3IiVLcBpdnp@handymancluster.cml1v.mongodb.net/authapp?retryWrites=true&w=majority")

app.listen(PORT, ()=> {
    console.info(`App listening on ${PORT}`)
})